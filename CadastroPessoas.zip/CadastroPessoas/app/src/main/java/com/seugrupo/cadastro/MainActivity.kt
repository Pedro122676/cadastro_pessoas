package com.seugrupo.cadastro

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

/**
 * Activity principal que exibe o formulário de cadastro de pessoas.
 * Utiliza um RelativeLayout como container principal e LinearLayouts horizontais
 * para alinhar rótulos e campos de texto.
 *
 * @author Equipe de Desenvolvimento
 */
class MainActivity : AppCompatActivity() {

    private val TAG = "MainActivityLifeCycle"
    private lateinit var etName: EditText
    private lateinit var etAge: EditText
    private lateinit var etAddress: EditText

    /**
     * Método de inicialização da Activity. Configura o layout e os ouvintes de clique.
     * @param savedInstanceState Estado salvo da instância, se houver.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "onCreate: Activity criada e iniciando componentes.")
        setContentView(R.layout.activity_main)

        // Inicialização dos componentes de UI
        etName = findViewById(R.id.et_name)
        etAge = findViewById(R.id.et_age)
        etAddress = findViewById(R.id.et_address)
        val btnSave: Button = findViewById(R.id.btn_save)

        // Verifica se há dados vindos da ResultActivity para pré-carregamento (Botão "Não")
        intent.extras?.let {
            etName.setText(it.getString("NAME"))
            etAge.setText(it.getString("AGE"))
            etAddress.setText(it.getString("ADDRESS"))
        }

        btnSave.setOnClickListener {
            val intent = Intent(this, ResultActivity::class.java).apply {
                putExtra("NAME", etName.text.toString())
                putExtra("AGE", etAge.text.toString())
                putExtra("ADDRESS", etAddress.text.toString())
            }
            startActivity(intent)
        }
    }

    /**
     * Infla o menu de opções na AppBar.
     * @param menu O menu no qual os itens são colocados.
     * @return true para exibir o menu.
     */
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    /**
     * Trata o clique nos itens do menu.
     * @param item O item de menu selecionado.
     * @return true se o evento foi consumido.
     */
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_about) {
            startActivity(Intent(this, AboutActivity::class.java))
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    // --- Métodos do Ciclo de Vida com diferentes níveis de Log ---

    override fun onStart() {
        super.onStart()
        Log.v(TAG, "onStart: A Activity está prestes a se tornar visível.")
    }

    override fun onResume() {
        super.onResume()
        Log.i(TAG, "onResume: A Activity está visível e pronta para interação.")
    }

    override fun onRestart() {
        super.onRestart()
        Log.i(TAG, "onRestart: A Activity está sendo reiniciada após ter sido parada.")
    }

    override fun onPause() {
        super.onPause()
        Log.w(TAG, "onPause: A Activity está perdendo o foco (visível, mas em pausa).")
    }

    override fun onStop() {
        super.onStop()
        Log.e(TAG, "onStop: A Activity não está mais visível para o usuário.")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "onDestroy: A Activity está sendo removida da memória.")
    }
}
