package com.seugrupo.cadastro

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * Activity que exibe os dados cadastrados na primeira tela para conferência.
 * Fornece opções para confirmar o salvamento ou retornar para edição.
 *
 * @author Equipe de Desenvolvimento
 */
class ResultActivity : AppCompatActivity() {

    private val TAG = "ResultActivityLifeCycle"
    private var name: String? = null
    private var age: String? = null
    private var address: String? = null

    /**
     * Inicializa a Activity de resultado, recupera os dados do Intent e os exibe.
     * @param savedInstanceState Estado salvo da instância.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "onCreate: Activity de conferência iniciada.")
        setContentView(R.layout.activity_result)

        val tvName: TextView = findViewById(R.id.tv_result_name)
        val tvAge: TextView = findViewById(R.id.tv_result_age)
        val tvAddress: TextView = findViewById(R.id.tv_result_address)
        val btnConfirm: Button = findViewById(R.id.btn_confirm)
        val btnBack: Button = findViewById(R.id.btn_back)

        // Recupera os dados extras enviados pela MainActivity
        name = intent.getStringExtra("NAME")
        age = intent.getStringExtra("AGE")
        address = intent.getStringExtra("ADDRESS")

        // Exibe os dados formatados concatenando os rótulos
        tvName.text = getString(R.string.label_name) + " " + (name ?: "")
        tvAge.text = getString(R.string.label_age) + " " + (age ?: "")
        tvAddress.text = getString(R.string.label_address) + " " + (address ?: "")

        // Configuração do botão de confirmação ("Sim")
        btnConfirm.setOnClickListener {
            Toast.makeText(this, R.string.toast_saved, Toast.LENGTH_SHORT).show()
            val intent = Intent(this, MainActivity::class.java)
            // FLAG_ACTIVITY_CLEAR_TOP limpa a pilha e volta para a instância existente da MainActivity
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(intent)
            finish()
        }

        // Configuração do botão de retorno ("Não")
        btnBack.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java).apply {
                putExtra("NAME", name)
                putExtra("AGE", age)
                putExtra("ADDRESS", address)
            }
            // Retorna para a MainActivity passando os dados de volta para serem re-preenchidos
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            startActivity(intent)
            finish()
        }
    }

    // --- Métodos do Ciclo de Vida para monitoramento em log ---

    override fun onStart() {
        super.onStart()
        Log.v(TAG, "onStart: Tela de conferência visível.")
    }

    override fun onResume() {
        super.onResume()
        Log.i(TAG, "onResume: Tela de conferência pronta.")
    }

    override fun onRestart() {
        super.onRestart()
        Log.i(TAG, "onRestart: Retornando à tela de conferência.")
    }

    override fun onPause() {
        super.onPause()
        Log.w(TAG, "onPause: Saindo da tela de conferência.")
    }

    override fun onStop() {
        super.onStop()
        Log.e(TAG, "onStop: Tela de conferência oculta.")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "onDestroy: Activity de conferência encerrada.")
    }
}
