package com.seugrupo.cadastro

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity

/**
 * Activity "Sobre" que exibe informações sobre os desenvolvedores do projeto.
 * Contém detalhes como nomes, RA's e curso.
 *
 * @author Equipe de Desenvolvimento
 */
class AboutActivity : AppCompatActivity() {

    private val TAG = "AboutActivityLifeCycle"

    /**
     * Inicializa a Activity de Sobre e configura a exibição do botão de retorno.
     * @param savedInstanceState Estado salvo da instância.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "onCreate: Activity Sobre criada.")
        setContentView(R.layout.activity_about)

        // Habilita a seta de retorno na Toolbar (Home button)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    /**
     * Trata o clique na seta de retorno na AppBar.
     * @return true para indicar que a navegação foi tratada.
     */
    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    // --- Métodos do Ciclo de Vida para monitoramento em log ---

    override fun onStart() {
        super.onStart()
        Log.v(TAG, "onStart: Tela Sobre visível.")
    }

    override fun onResume() {
        super.onResume()
        Log.i(TAG, "onResume: Tela Sobre pronta para leitura.")
    }

    override fun onRestart() {
        super.onRestart()
        Log.i(TAG, "onRestart: Retornando à tela Sobre.")
    }

    override fun onPause() {
        super.onPause()
        Log.w(TAG, "onPause: Saindo da tela Sobre.")
    }

    override fun onStop() {
        super.onStop()
        Log.e(TAG, "onStop: Tela Sobre oculta.")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "onDestroy: Activity Sobre destruída.")
    }
}
